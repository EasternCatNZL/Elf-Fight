﻿using UnityEngine;
using System.Collections;

public class InitPlayer : MonoBehaviour {

    public int Player;

	// Use this for initialization
	void Start () {
        if (Player == 1)
        {

        }
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
