﻿using UnityEngine;
using System.Collections;

public class LoadCharacterSelect : MonoBehaviour {
	
	public void LoadScene()
    {
        Application.LoadLevel("CharSelect");
    }
}
